﻿namespace Login
{
    partial class frmDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.messageDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.messagesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.loginTestDataSet1 = new Login.LoginTestDataSet1();
            this.dashboardMessages = new Login.DashboardMessages();
            this.dashboardMessagesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.btnSendMessage = new System.Windows.Forms.Button();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.idDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateTimeDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.messageDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.messagesBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.loginTestDataSet2BindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.loginTestDataSet2 = new Login.LoginTestDataSet2();
            this.loginTestDataSet31 = new Login.LoginTestDataSet3();
            this.messagesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.messagesTableAdapter1 = new Login.LoginTestDataSet2TableAdapters.MessagesTableAdapter();
            this.messagesTableAdapter = new Login.LoginTestDataSet1TableAdapters.MessagesTableAdapter();
            this.messagesBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardMessages)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardMessagesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet2BindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource2)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn,
            this.dateTimeDataGridViewTextBoxColumn,
            this.messageDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.messagesBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 52);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(350, 239);
            this.dataGridView1.TabIndex = 2;
            // 
            // idDataGridViewTextBoxColumn
            // 
            this.idDataGridViewTextBoxColumn.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn.Name = "idDataGridViewTextBoxColumn";
            this.idDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateTimeDataGridViewTextBoxColumn
            // 
            this.dateTimeDataGridViewTextBoxColumn.DataPropertyName = "DateTime";
            this.dateTimeDataGridViewTextBoxColumn.HeaderText = "DateTime";
            this.dateTimeDataGridViewTextBoxColumn.Name = "dateTimeDataGridViewTextBoxColumn";
            // 
            // messageDataGridViewTextBoxColumn
            // 
            this.messageDataGridViewTextBoxColumn.DataPropertyName = "Message";
            this.messageDataGridViewTextBoxColumn.HeaderText = "Message";
            this.messageDataGridViewTextBoxColumn.Name = "messageDataGridViewTextBoxColumn";
            // 
            // messagesBindingSource
            // 
            this.messagesBindingSource.DataMember = "Messages";
            this.messagesBindingSource.DataSource = this.loginTestDataSet1;
            // 
            // loginTestDataSet1
            // 
            this.loginTestDataSet1.DataSetName = "LoginTestDataSet1";
            this.loginTestDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dashboardMessages
            // 
            this.dashboardMessages.DataSetName = "DashboardMessages";
            this.dashboardMessages.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dashboardMessagesBindingSource
            // 
            this.dashboardMessagesBindingSource.DataSource = this.dashboardMessages;
            this.dashboardMessagesBindingSource.Position = 0;
            // 
            // btnSendMessage
            // 
            this.btnSendMessage.Font = new System.Drawing.Font("Palatino Linotype", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSendMessage.Location = new System.Drawing.Point(104, 384);
            this.btnSendMessage.Name = "btnSendMessage";
            this.btnSendMessage.Size = new System.Drawing.Size(146, 44);
            this.btnSendMessage.TabIndex = 1;
            this.btnSendMessage.Text = "Send Message";
            this.btnSendMessage.UseVisualStyleBackColor = true;
            this.btnSendMessage.Click += new System.EventHandler(this.btnSendMessage_Click);
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(12, 343);
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(350, 20);
            this.txtMessage.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Control;
            this.label2.Font = new System.Drawing.Font("Open Sans", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 313);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 18);
            this.label2.TabIndex = 8;
            this.label2.Text = "Enter your message here:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Font = new System.Drawing.Font("Cambria", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(80, 9);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(200, 28);
            this.label3.TabIndex = 9;
            this.label3.Text = "A super-real chat";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idDataGridViewTextBoxColumn1,
            this.dateTimeDataGridViewTextBoxColumn1,
            this.messageDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.messagesBindingSource3;
            this.dataGridView2.Location = new System.Drawing.Point(11, 52);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(351, 239);
            this.dataGridView2.TabIndex = 10;
            // 
            // idDataGridViewTextBoxColumn1
            // 
            this.idDataGridViewTextBoxColumn1.DataPropertyName = "Id";
            this.idDataGridViewTextBoxColumn1.HeaderText = "Id";
            this.idDataGridViewTextBoxColumn1.Name = "idDataGridViewTextBoxColumn1";
            this.idDataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dateTimeDataGridViewTextBoxColumn1
            // 
            this.dateTimeDataGridViewTextBoxColumn1.DataPropertyName = "DateTime";
            this.dateTimeDataGridViewTextBoxColumn1.HeaderText = "DateTime";
            this.dateTimeDataGridViewTextBoxColumn1.Name = "dateTimeDataGridViewTextBoxColumn1";
            // 
            // messageDataGridViewTextBoxColumn1
            // 
            this.messageDataGridViewTextBoxColumn1.DataPropertyName = "Message";
            this.messageDataGridViewTextBoxColumn1.HeaderText = "Message";
            this.messageDataGridViewTextBoxColumn1.Name = "messageDataGridViewTextBoxColumn1";
            // 
            // messagesBindingSource3
            // 
            this.messagesBindingSource3.DataMember = "Messages";
            this.messagesBindingSource3.DataSource = this.loginTestDataSet2BindingSource;
            // 
            // loginTestDataSet2BindingSource
            // 
            this.loginTestDataSet2BindingSource.DataSource = this.loginTestDataSet2;
            this.loginTestDataSet2BindingSource.Position = 0;
            // 
            // loginTestDataSet2
            // 
            this.loginTestDataSet2.DataSetName = "LoginTestDataSet2";
            this.loginTestDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // loginTestDataSet31
            // 
            this.loginTestDataSet31.DataSetName = "LoginTestDataSet3";
            this.loginTestDataSet31.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // messagesBindingSource1
            // 
            this.messagesBindingSource1.DataMember = "Messages";
            this.messagesBindingSource1.DataSource = this.loginTestDataSet2BindingSource;
            // 
            // messagesTableAdapter1
            // 
            this.messagesTableAdapter1.ClearBeforeFill = true;
            // 
            // messagesTableAdapter
            // 
            this.messagesTableAdapter.ClearBeforeFill = true;
            // 
            // messagesBindingSource2
            // 
            this.messagesBindingSource2.DataMember = "Messages";
            this.messagesBindingSource2.DataSource = this.loginTestDataSet2BindingSource;
            // 
            // frmDashboard
            // 
            this.AcceptButton = this.btnSendMessage;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.BackgroundImage = global::Login.Properties.Resources._3;
            this.ClientSize = new System.Drawing.Size(374, 440);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMessage);
            this.Controls.Add(this.btnSendMessage);
            this.Controls.Add(this.dataGridView1);
            this.Name = "frmDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dashboard";
            this.Load += new System.EventHandler(this.frmDashboard_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardMessages)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dashboardMessagesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet2BindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.loginTestDataSet31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.messagesBindingSource2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource dashboardMessagesBindingSource;
        private DashboardMessages dashboardMessages;
        private LoginTestDataSet1 loginTestDataSet1;
        private System.Windows.Forms.BindingSource messagesBindingSource;
        private LoginTestDataSet1TableAdapters.MessagesTableAdapter messagesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateTimeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn messageDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnSendMessage;
        private System.Windows.Forms.TextBox txtMessage;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private LoginTestDataSet3 loginTestDataSet31;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource loginTestDataSet2BindingSource;
        private LoginTestDataSet2 loginTestDataSet2;
        private System.Windows.Forms.BindingSource messagesBindingSource1;
        private LoginTestDataSet2TableAdapters.MessagesTableAdapter messagesTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn idDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateTimeDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn messageDataGridViewTextBoxColumn1;
        private System.Windows.Forms.BindingSource messagesBindingSource3;
        private System.Windows.Forms.BindingSource messagesBindingSource2;
    }
}