﻿namespace Login
{
    internal class sqlParameter
    {
    }
}