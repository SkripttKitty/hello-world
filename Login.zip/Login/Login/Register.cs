﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Net.Mail;
using System.Net;


namespace Login
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }

        //If the form Login is clicked
        private void lblLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.Show();
            this.Hide();
        }

        //Closing the Register form
        private void Register_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// After the user entered register credentials and the button "Register" has been clicked, the list of new sql parameters is created
        /// (username, password and email). The store procedure "ValidateLogin" gets executed. If login credentials are valid, the store procedure 
        /// "Create New User" gets executed. The email is sent to the users email adress congratulating the user on registering. 
        /// If credentials are invalid, the error message asking user to enter valid credentials gets displayed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRegister_Click(object sender, EventArgs e)
        {
            List<SqlParameter> sqlParams = new List<SqlParameter>();//inputing the sql parameters
            sqlParams.Add(new SqlParameter("Username", txtUser.Text));
            sqlParams.Add(new SqlParameter("Password", txtPassword.Text));
            sqlParams.Add(new SqlParameter("Email", txtEmail.Text));

            DataTable dtLoginResults = MyFirstChapApplication.DAL.ExecStoredProcedure("ValidateLogin", sqlParams);//validating the login
            // If username does not exist
            if (dtLoginResults.Rows.Count > 0)
            {
                
                MessageBox.Show("Please pick a different username ", "Error");
            }
            else
            {
                List<SqlParameter> sqlParams1 = new List<SqlParameter>();//inputing the sql parameters
                sqlParams1.Add(new SqlParameter("Username", txtUser.Text));
                sqlParams1.Add(new SqlParameter("Password", txtPassword.Text));
                sqlParams1.Add(new SqlParameter("Email", txtEmail.Text));

                //Executing Create User store procedure
                MyFirstChapApplication.DAL.ExecStoredProcedure("CreateUser", sqlParams1);

                MessageBox.Show("New user created");//new user has been created

                // variables to store the email registered and also the email used to send the email
                string email = txtEmail.Text.Trim(),
                       myemail = "dbprogramminglogin@outlook.com";

                MailMessage registration = new MailMessage();
                registration.From = new MailAddress(myemail);
                registration.To.Add(new MailAddress(email));
                //Below code is for the email subject and body
                registration.Subject = "Registration Confirmation";
                registration.Body = "Dear New User,<br><br> Welcome to chat! <br>Thanks for Registering!<br><br> Anna";
                //The client and port used to send the email based on the email server
                SmtpClient smtp = new SmtpClient("smtp.live.com", 587);
                registration.IsBodyHtml = true;

                //Credentials for sending the email on the account used.
                NetworkCredential Credentials = new NetworkCredential(myemail, "Canada1996");
                smtp.Credentials = Credentials;
                smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtp.EnableSsl = true;

                smtp.Send(registration);
            }//end else
           
            
        }//end btn Register clcik event
    }
}
