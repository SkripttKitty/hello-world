﻿using MyFirstChapApplication;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Login
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }


        //
        /// <summary>
        ///After the user entered login credentials and the button "Login" has been clicked, the list of new sql parameters is created
        /// (username, password and email). The store procedure "ValidateLogin" gets executed. If login credentials are valid,
        /// user gets logged in and is prompted to the dashboard window.
        /// If login credetials are invalid, user gets an erro message asking him to enter valid credentials.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnLogin_Click(object sender, EventArgs e)
        {
            List<SqlParameter> sqlParams = new List<SqlParameter>();
            sqlParams.Add(new SqlParameter("Username", txtUser.Text));
            sqlParams.Add(new SqlParameter("Password", txtPassword.Text));
            sqlParams.Add(new SqlParameter("Email", txtEmail2.Text));
            

            //Executing store procedure
            DataTable dtLoginResults = DAL.ExecStoredProcedure("ValidateLogin", sqlParams);

            if(dtLoginResults.Rows.Count == 1)
            {
                //The login is valid
                string user = dtLoginResults.Rows[0]["Username"].ToString();
                MessageBox.Show("You are logged in as " + user, "Login Confirmation");

                //Show the dashboard
                frmDashboard objFrmDashboard = new frmDashboard();

                //hide the Login form and prompt user to a dashboard
                this.Hide();
                objFrmDashboard.Show();
            }
            else
            {
                //If the login is invalid
                MessageBox.Show("Invalid Login Credentials");
            }


        }
        //when yser clicks on registration form
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //Opening a register form if "register" button is clicked
            Register frmRegister = new Register();
            frmRegister.Show();
            this.Hide();
        }

        //Closing the Login form if user clicked "Register" button
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();//exiting the application
        }
    }
}
