﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Login
{
    public partial class frmDashboard : Form
    {
        public frmDashboard()
        {
            InitializeComponent();
        }

        private void frmDashboard_Load(object sender, EventArgs e)
        {
            //filling the table adapter with existing data
            this.messagesTableAdapter1.Fill(this.loginTestDataSet2.Messages);
          
            this.messagesTableAdapter.Fill(this.loginTestDataSet1.Messages);
        }


        /// <summary>
        /// After the user has typed the Message for the chat, the stored procedure which sends message to the database gets executed.
        /// The user gets a message confirming, that the message which was typed in, has been sent. The store procedure for pulling the message gets executed 
        /// and the message gets displayed in the chat.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSendMessage_Click(object sender, EventArgs e)
        {            
           //inuting the sql parameters
            List<SqlParameter> sqlParams = new List<SqlParameter>();
            sqlParams.Add(new SqlParameter("Message", txtMessage.Text));
            sqlParams.Add(new SqlParameter("DateTime", DateTimeOffset.Now));

           //executing "Send message" store procedure
            DataTable dtMessages = MyFirstChapApplication.DAL.ExecStoredProcedure("SendMessage", sqlParams);

            
            MessageBox.Show("Your message has been sent");
            dataGridView1.Hide();
            txtMessage.Clear();
         
            //set new parameters for a store procedure
            List<SqlParameter> sqlParams1 = new List<SqlParameter>();

            //displaying new message
            DataTable dtbMessages = MyFirstChapApplication.DAL.ExecStoredProcedure("DisplayMessages", sqlParams1);
            this.messagesTableAdapter1.Fill(this.loginTestDataSet2.Messages);
            dataGridView2.Refresh();

        }



        //checking for errors
        private void fillByToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.messagesTableAdapter.FillBy(this.loginTestDataSet1.Messages);
           
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }

        private void fillBy1ToolStripButton_Click(object sender, EventArgs e)
        {
            try
            {
                this.messagesTableAdapter.FillBy1(this.loginTestDataSet1.Messages);
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }

        }
    }
}
